/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica1;
import java.util.Scanner;

/**
 *
 * @author David Lazaro
 */
public class Practica1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int number = 0;
        Scanner input = new Scanner(System.in);
        do{
        System.out.println("Ingresa la operacion que desees realizar");
        System.out.printf(" 1.-Suma \n 2.- Resta \n 3.- Multiplicacion \n 4.- Division\n\n");
        int n = input.nextInt(); 
        int a,b,c;
        
        float d,e,f;
        
        switch(n){
            case 1:
                    System.out.println("Ingrese el valor del primer numero a sumar: ");
                    a= input.nextInt();
                    System.out.println("Ingrese el valor del segundo numero a sumar: ");
                    b= input.nextInt();
                    c= a+b;
                    System.out.println("La suma total de los 2 numeros es: " + c);
                    break;
            case 2:
                    System.out.println("Ingrese el valor del primer numero a restar: ");
                    a= input.nextInt();
                    System.out.println("Ingrese el valor del segundo numero a restar: ");
                    b= input.nextInt();
                    c= a-b;
                    System.out.println("La resta total de los 2 numeros es: " + c);
                    break;
            case 3:
                    System.out.println("Ingrese el valor del primer numero a multiplicar: ");
                    a= input.nextInt();
                    System.out.println("Ingrese el valor del segundo numero a multiplicar: ");
                    b= input.nextInt();
                    c= a*b;
                    System.out.println("La multiplicacion total de los 2 numeros es: " + c);
                    break;
            case 4:
                    System.out.println("Ingrese el valor del primer numero a dividir: ");
                    d= input.nextFloat();
                    System.out.println("Ingrese el valor del segundo numero a dividir: ");
                    e= input.nextFloat();
                    f= d/e;
                    System.out.println("La multiplicacion total de los 2 numeros es: " + f);
                    break;        
            }        
        System.out.println("¿Desea seguir realizando operaciones? [1.-Si | 2.- No]");
        number = input.nextInt();
        }while(number != 2);
        
    }
}
                
    

